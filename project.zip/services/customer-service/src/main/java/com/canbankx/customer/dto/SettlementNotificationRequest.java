package com.canbankx.customer.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SettlementNotificationRequest {
    
    // Our internal transaction ID
    private String externalTransactionId;
    
    // Central Bank's transaction ID
    private String centralBankTransactionId;
    
    // Final result: SETTLED, REJECTED, EXPIRED
    private String result;
    
    // Reason (if REJECTED or EXPIRED)
    private String reason;
    
    // When Central Bank finalized it
    private Instant settledAt;
    
    // Idempotency key (so we don't process same settlement twice)
    private String idempotencyKey;
}
